#!/bin/bash
set -euo pipefail

cd web
sh ./compile_wasm.sh
