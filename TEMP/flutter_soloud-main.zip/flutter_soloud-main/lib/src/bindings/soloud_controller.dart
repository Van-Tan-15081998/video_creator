export 'package:flutter_soloud/src/bindings/soloud_controller_ffi.dart'
    if (dart.library.js_interop) 'package:flutter_soloud/src/bindings/soloud_controller_web.dart';
