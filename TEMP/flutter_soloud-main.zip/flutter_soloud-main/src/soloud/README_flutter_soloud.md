## flutter_soloud

This is the forked folder of [SoLoud](https://github.com/jarikomppa/soloud) library. To save space not all content is stored here.

Some SoLoud sources has been modified to meet the `flutter_soloud` needs. You can find a fork of `SoLoud` with the changes [here](https://github.com/alnitak/soloud/tree/flutter_soloud).