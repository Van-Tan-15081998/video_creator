#ifndef ACTIVE_SOUND_FWD_H
#define ACTIVE_SOUND_FWD_H

struct ActiveSound;

#endif // ACTIVE_SOUND_FWD_H
