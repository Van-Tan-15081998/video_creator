#ifndef FILTERS_FWD_H
#define FILTERS_FWD_H

#include "enums.h"

class Filters;
struct FilterObject;

#endif // FILTERS_FWD_H
