#!/bin/bash
set -euo pipefail

cd web
sh ./compile_worker_and_init_module.sh
